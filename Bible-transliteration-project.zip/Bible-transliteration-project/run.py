from app import app
from app import routes

if __name__ == '__main__':
    app.run()