class Config:
    SECRET_KEY = 'your-secret-key'
    # Add any other configuration variables here